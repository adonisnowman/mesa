<?php
$SIGNALING_ADDRESS = 'wss://adonis.tw:9509';
// $SIGNALING_ADDRESS = 'wss://adonis.tw:8080';
//$STUN_ADDRESS = 'stun:stun.xten.com';
